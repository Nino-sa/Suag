function Voltar() {
  window.location.href = "caminho/arquivo/inicio";
}
